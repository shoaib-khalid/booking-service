/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.controller;

import com.kalsym.service.vertical.model.Reservation;
import com.kalsym.service.vertical.service.ReservationService;
import com.kalsym.service.vertical.utility.HttpResponse;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author hasan
 */
@RestController
@RequestMapping("/{storeId}/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @GetMapping(path = {""}, name = "reservation-get", produces = "application/json")
    public ResponseEntity<HttpResponse> getReservation(HttpServletRequest request,
            @PathVariable String storeId) {

        return reservationService.getReservation(request, storeId);
    }

    @GetMapping(path = {"/{reservationId}"}, name = "reservation-get-by-id", produces = "application/json")
    public ResponseEntity<HttpResponse> getReservationById(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable(required = true) String reservationId) {

        return reservationService.getReservationById(request, storeId, reservationId);
    }

    @PostMapping(path = {"/{slotId}"}, name = "reservation-post", produces = "application/json")
    public ResponseEntity<HttpResponse> postReservation(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable(required = true) String slotId,
            @RequestBody Reservation bodyReservation) {
        return reservationService.postReservation(request,
                storeId,
                slotId,
                bodyReservation);
    }


    @PutMapping(path = {"/{id}"}, name = "reservation-put", produces = "application/json")
    public ResponseEntity<HttpResponse> putReservation(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable String id,
            @RequestBody Reservation bodyReservation) {

        return reservationService.putReservation(request, storeId, id, bodyReservation);
    }

    @DeleteMapping(path = {"/{id}"}, name = "reservation-delete-by-id", produces = "application/json")
    public ResponseEntity<HttpResponse> deleteReservationSlotById(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable String id) {
        return reservationService.deleteReservationById(request, storeId, id);
    }

}
