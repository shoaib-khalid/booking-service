/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.controller;

import com.kalsym.service.vertical.model.ReservationResource;
import com.kalsym.service.vertical.service.ReservationResourceService;
import com.kalsym.service.vertical.utility.HttpResponse;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author hasan
 */
@RestController
@RequestMapping("/{storeId}/reservations/resources")
public class ReservationResourceController {

    @Autowired
    private ReservationResourceService reservationResourceService;

    @GetMapping(path = {""}, name = "reservation-resoruce-get", produces = "application/json")
    public ResponseEntity<HttpResponse> getReservationResource(HttpServletRequest request,
            @PathVariable(required = true) String storeId) {
        return reservationResourceService.getReservationResource(request, storeId);
    }

    @GetMapping(path = {"/{id}"}, name = "reservation-resource-get-by-id", produces = "application/json")
    public ResponseEntity<HttpResponse> getReservationResourceById(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable(required = true) String id) {
        return reservationResourceService.getReservationResourceById(request, storeId, id);
    }

    @PostMapping(path = {"/{productId}"}, name = "reservation-resource-post", produces = "application/json")
    public ResponseEntity<HttpResponse> postReservationResource(HttpServletRequest request,
            @PathVariable(required = true) String storeId,
            @PathVariable(required = true) String productId,
            @RequestBody ReservationResource bodyReservationResource) {
        return reservationResourceService.postReservationResource(request, storeId, productId, bodyReservationResource);
    }

    @PutMapping(path = {"/{id}"}, name = "reservation-resource-put", produces = "application/json")
    public ResponseEntity<HttpResponse> putReservationResoruce(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable String id,
            @RequestBody ReservationResource bodyReservationResource) {

        return reservationResourceService.putReservationResoruce(request, storeId, id, bodyReservationResource);
    }

    @DeleteMapping(path = {"/{id}"}, name = "reservation-resoruce-delete-by-id", produces = "application/json")
    public ResponseEntity<HttpResponse> deleteReservationResourceById(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable String id) {
        return reservationResourceService.deleteReservationResourceById(request, storeId, id);
    }
}
