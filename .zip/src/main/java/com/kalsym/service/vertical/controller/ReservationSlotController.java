/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.controller;

import com.kalsym.service.vertical.model.ReservationSlot;
import com.kalsym.service.vertical.service.ReservationSlotService;
import com.kalsym.service.vertical.utility.HttpResponse;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author hasan
 */
@RestController
@RequestMapping("/{storeId}/reservations/slots")
public class ReservationSlotController {

    @Autowired
    private ReservationSlotService reservationSlotService;

    @GetMapping(path = {""}, name = "reservation-slot-get", produces = "application/json")
    public ResponseEntity<HttpResponse> getReservationSlot(HttpServletRequest request,
            @PathVariable(name = "storeId") String storeId) {

        return reservationSlotService.getReservationSlot(request, storeId);
    }

    @GetMapping(path = {"/{slotId}"}, name = "reservation-slot-get-by-id", produces = "application/json")
    public ResponseEntity<HttpResponse> getReservedSlots(HttpServletRequest request,
            @PathVariable(name = "storeId") String storeId,
            @PathVariable(name = "slotId", required = true) String slotId) {

        return reservationSlotService.getReservationSlotById(request, storeId, slotId);
    }

    @GetMapping(path = {"/reserved"}, name = "reservation-slot-get-reserved", produces = "application/json")
    public ResponseEntity<HttpResponse> getReservedSlots(HttpServletRequest request,
            @PathVariable String storeId) {

        return reservationSlotService.getReservedSlots(request, storeId);
    }

    @GetMapping(path = {"/unreserved/{slotId}"}, name = "reservation-slot-create-reservation-slot-id", produces = "application/json")
    public ResponseEntity<HttpResponse> createReservationSlots(HttpServletRequest request,
            @PathVariable(name = "storeId") String storeId,
            @PathVariable(name = "slotId", required = true) String slotId) {
        return reservationSlotService.getUnreservedSlots(request, storeId, slotId);
    }

    @PostMapping(path = {"/{resourceId}"}, name = "reservation-slot-post", produces = "application/json")
    public ResponseEntity<HttpResponse> postReservationSlot(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable(name = "resourceId") String resourceId,
            @RequestBody ReservationSlot bodyReservationSlot) {
        return reservationSlotService.postReservationSlot(request,
                storeId,
                resourceId,
                bodyReservationSlot);
    }

    @PutMapping(path = {"/{slotId}"}, name = "reservation-slot-put", produces = "application/json")
    public ResponseEntity<HttpResponse> putReservationSlot(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable(name = "slotId") String id,
            @RequestBody ReservationSlot bodyReservationSlot) {

        return reservationSlotService.putReservationSlot(request, storeId, id, bodyReservationSlot);
    }

    @DeleteMapping(path = {"/{slotId}"}, name = "reservation-slot-delete-by-id", produces = "application/json")
    public ResponseEntity<HttpResponse> deleteReservationSlotById(HttpServletRequest request,
            @PathVariable String storeId,
            @PathVariable(name = "slotId") String slotId) {
        return reservationSlotService.deleteReservationSlotById(request, storeId, slotId);
    }

}
