/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.enums;

/**
 *
 * @author hasan
 */
public enum AvailabilityDay {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY,
    MONDAY_FRIDAY,
    EVERYDAY,
    SATURDAY_SUNDAY,
    FRIDAY_SUNDAY
}
//ENUM('MONDAY','TUESDAY','WEDNESDAT','THURSDAY','FRIDAY','SATURDAY','SUNDAY','MONDAY_FRIDAY','SATURDAY_SUNDAY','FRIDAY_SUNDAY','EVERYDAY')