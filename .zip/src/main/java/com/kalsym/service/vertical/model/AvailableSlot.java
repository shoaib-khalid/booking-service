/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.model;

import com.kalsym.service.vertical.enums.AvailabilityDay;
import java.time.DayOfWeek;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author hasan
 */
@Data
@NoArgsConstructor
public class AvailableSlot {
   private String day;
   private long startTime;
   private long endTime;
}
