/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.model;

import com.kalsym.service.vertical.enums.ReservationStatus;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

/**
 *
 * @author hasan
 */
@Entity
@Table(name = "resource_slot_reservation_detail")
@Data
@NoArgsConstructor
public class Reservation implements Serializable {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "id", length = 50)
    private String id;

    @Column(name = "customerName",length = 50)
    private String customerName;
    
    @Column(name = "customerEmail", length = 50)
    private String customerEmail;
    
    @Column(name = "customerPhoneNumber", length = 50)
    private String customerPhoneNumber;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private ReservationStatus status;

    @Column(name = "customerNotes", length = 200)
    private String customerNotes;

    @CreationTimestamp
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date created;

    @UpdateTimestamp
    private LocalDateTime updated;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL, optional = false)
    @JoinColumn(name = "reservationSlotId", referencedColumnName = "id", nullable = false)
    private ReservationSlot reservationSlot;

    public void update(Reservation reservation) {
        
        if(reservation.getCustomerName() != null){
            customerName = reservation.getCustomerName();
        }
        
        if(reservation.getCustomerEmail() != null){
            customerEmail = reservation.getCustomerEmail();
        }
        
        if (reservation.getCustomerNotes() != null) {
            customerNotes = reservation.getCustomerNotes();
        }

        if (reservation.getStatus() != null) {
            status = reservation.getStatus();
        }
        
        if (reservation.getCustomerPhoneNumber() != null){
            customerPhoneNumber = reservation.getCustomerPhoneNumber();
        }
    }
}
