/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.kalsym.service.vertical.enums.AvailabilityDay;
import com.kalsym.service.vertical.enums.ConfirmationMethod;
import com.kalsym.service.vertical.model.product.Product;
import com.kalsym.service.vertical.model.store.Store;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

/**
 *
 * @author hasan
 */
@Entity
@Table(name = "resource_availability")
@Data
@NoArgsConstructor
public class ReservationResource implements Serializable {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "id", length = 50)
    private String id;

    @Column(name = "availabilityDay")
    @Enumerated(EnumType.STRING)
    private AvailabilityDay availabilityDay;

    @Column(name = "durationInMinutes", nullable = false)
    private Integer durationInMinutes;

    @Column(name = "startTime", nullable = false)
    @JsonFormat(pattern = "HH:mm")
    private LocalTime startTime;

    @Column(name = "endTime", nullable = false)
    @JsonFormat(pattern = "HH:mm")
    private LocalTime endTime;

    @Column(name = "minimumTimeBetweenReservation")
    private Integer minimumTimeBetweenReservation;

    @Column(name = "confirmationMethod")
    @Enumerated(EnumType.STRING)
    private ConfirmationMethod confirmationMethod;

    @Column(name = "description", length = 200)
    private String description;

    @Column(name = "numberOfWeeksReservable")
    private Integer numberOfWeeksReservable;

    @CreationTimestamp
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date created;

    @UpdateTimestamp
    private LocalDateTime updated;

    @OneToMany(mappedBy = "reservationResource")
    @JsonManagedReference
    private List<ReservationSlot> reservedSlots;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "productId", referencedColumnName = "id", nullable = false)
    private Product product;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "storeId", referencedColumnName = "id")
    @JsonIgnore
    /**
     * The Store of the resource
     */
    private Store store;

    public void update(ReservationResource reservationResource) {

        if (reservationResource.getAvailabilityDay() != null) {
            availabilityDay = reservationResource.getAvailabilityDay();
        }

        if (reservationResource.getDurationInMinutes() != null) {
            durationInMinutes = reservationResource.getDurationInMinutes();
        }

        if (reservationResource.getStartTime() != null) {
            startTime = reservationResource.getStartTime();
        }

        if (reservationResource.getEndTime() != null) {
            endTime = reservationResource.getEndTime();
        }

        if (reservationResource.getMinimumTimeBetweenReservation() != null) {
            minimumTimeBetweenReservation = reservationResource.getMinimumTimeBetweenReservation();
        }

        if (reservationResource.getDescription() != null) {
            description = reservationResource.getDescription();
        }

        if (reservationResource.getNumberOfWeeksReservable() != null) {
            numberOfWeeksReservable = reservationResource.getNumberOfWeeksReservable();
        }
    }

}
