/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.service;

import com.kalsym.service.vertical.ServiceVerticalApplication;
import com.kalsym.service.vertical.model.ReservationResource;
import com.kalsym.service.vertical.model.product.Product;
import com.kalsym.service.vertical.model.store.Store;
import com.kalsym.service.vertical.repository.ProductRepository;
import com.kalsym.service.vertical.repository.ReservationResourceRepository;
import com.kalsym.service.vertical.repository.StoreRepository;
import com.kalsym.service.vertical.utility.HttpResponse;
import com.kalsym.service.vertical.utility.Logger;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 *
 * @author hasan
 */
@Service
public class ReservationResourceService {

    @Autowired
    private ReservationResourceRepository reservationResourceRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    StoreRepository storeRepository;

    public ResponseEntity<HttpResponse> getReservationResource(HttpServletRequest request,
            String storeId) {

        String logPrefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        List<ReservationResource> reservationResources = reservationResourceRepository.findByStoreId(storeId);

        response.setStatus(HttpStatus.OK);
        response.setData(reservationResources);
        return ResponseEntity.status(response.getStatus()).body(response);

    }

    public ResponseEntity<HttpResponse> getReservationResourceById(HttpServletRequest request,
            String storeId,
            String id) {

        String logPrefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationResource> optReservationResource = reservationResourceRepository.findById(id);

        if (!optReservationResource.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND id: " + id);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        response.setStatus(HttpStatus.OK);
        response.setData(optReservationResource.get());
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    public ResponseEntity<HttpResponse> postReservationResource(HttpServletRequest request,
            String storeId,
            String productId,
            ReservationResource bodyReservationResource) {

        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "bodyReservationResource: " + bodyReservationResource.toString());

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " FOUND storeId: " + storeId);

        Optional<Product> optProduct = productRepository.findById(productId);

        if (!optProduct.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "NOT_FOUND: {}", productId);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        bodyReservationResource.setProduct(optProduct.get());

        List<ReservationResource> reservationResources = reservationResourceRepository.findAll();

        for (ReservationResource existingReservationResource : reservationResources) {
            if (existingReservationResource.getProduct().getId().equals(bodyReservationResource.getProduct().getId())
                    && existingReservationResource.getStartTime().equals(bodyReservationResource.getStartTime())
                    && existingReservationResource.getEndTime().equals(bodyReservationResource.getEndTime())) {
                Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "resource already exists", "");
                response.setStatus(HttpStatus.CONFLICT);
                response.setData("Resource Already Exists");
                return ResponseEntity.status(response.getStatus()).body(response);
            }
        }

        for (ReservationResource existingReservationResource : reservationResources) {
            if (existingReservationResource.getProduct().getId().equals(bodyReservationResource.getProduct().getId())
                    && existingReservationResource.getStartTime().equals(bodyReservationResource.getStartTime())
                    && existingReservationResource.getEndTime().equals(bodyReservationResource.getEndTime())
                    && existingReservationResource.getDurationInMinutes().equals(bodyReservationResource.getDurationInMinutes())
                    && existingReservationResource.getAvailabilityDay().toString().equals(bodyReservationResource.getAvailabilityDay().toString())) {
                Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "resource duration overlapping", "");
                response.setStatus(HttpStatus.CONFLICT);
                response.setData("Resource duration overlapping");
                return ResponseEntity.status(response.getStatus()).body(response);
            }
        }

        for (ReservationResource existingReservationResource : reservationResources) {
            if (existingReservationResource.getProduct().getId().equals(bodyReservationResource.getProduct().getId())
                    && existingReservationResource.getStartTime().isBefore(bodyReservationResource.getStartTime())
                    && existingReservationResource.getEndTime().isBefore(bodyReservationResource.getStartTime())
                    && existingReservationResource.getDurationInMinutes().equals(bodyReservationResource.getDurationInMinutes())
                    && existingReservationResource.getAvailabilityDay().toString().equals(bodyReservationResource.getAvailabilityDay().toString())) {
                Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "resource duration overlapping", "");
                response.setStatus(HttpStatus.CONFLICT);
                response.setData("Resource duration overlapping");
                return ResponseEntity.status(response.getStatus()).body(response);
            }
        }

        if (bodyReservationResource.getMinimumTimeBetweenReservation() == null) {
            bodyReservationResource.setMinimumTimeBetweenReservation(0);
        }

        if (bodyReservationResource.getDescription() == null) {
            bodyReservationResource.setDescription("");
        }

        if (bodyReservationResource.getNumberOfWeeksReservable() == null) {
            bodyReservationResource.setNumberOfWeeksReservable(12);
        }

        bodyReservationResource.setStore(optStore.get());
        ReservationResource savedReservationResource = reservationResourceRepository.save(bodyReservationResource);

        response.setStatus(HttpStatus.CREATED);
        response.setData(savedReservationResource);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    public ResponseEntity<HttpResponse> putReservationResoruce(HttpServletRequest request,
            String storeId,
            String id,
            ReservationResource bodyReservationResource) {

        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationResource> optReservationResoruce = reservationResourceRepository.findById(id);

        if (!optReservationResoruce.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "NOT_FOUND: {}", id);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation Resource found with Id: {}", id);
        ReservationResource reservationResource = optReservationResoruce.get();

        reservationResource.update(bodyReservationResource);

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation Resource updated for Id: " + id, "");
        response.setStatus(HttpStatus.ACCEPTED);
        response.setData(reservationResourceRepository.save(reservationResource));
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }

    public ResponseEntity<HttpResponse> deleteReservationResourceById(HttpServletRequest request,
            String storeId,
            String id) {
        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationResource> optReservationResource = reservationResourceRepository.findById(id);

        if (!optReservationResource.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND: " + id, "");
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation Resource found", "");
        reservationResourceRepository.delete(optReservationResource.get());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "product deleted, with id: {}", id);
        response.setStatus(HttpStatus.OK);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

}


//'000ee780-2e76-4e77-a56f-9d28830f111c', 'fd7b63b1-9f78-47d3-a569-2d146d205e1a', 'demo-product-id', 'MONDAY', '18:00:00', '20:00:00', '15', '12', '0', 'DEFAULT', '', '2022-04-19 15:43:08', '2022-04-25 10:07:28'
