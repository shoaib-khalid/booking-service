/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.service;

import com.kalsym.service.vertical.ServiceVerticalApplication;
import com.kalsym.service.vertical.enums.ReservationStatus;
import com.kalsym.service.vertical.model.Reservation;
import com.kalsym.service.vertical.model.ReservationSlot;
import com.kalsym.service.vertical.model.store.Store;
import com.kalsym.service.vertical.repository.ReservationRepository;
import com.kalsym.service.vertical.repository.ReservationSlotRepository;
import com.kalsym.service.vertical.repository.StoreRepository;
import com.kalsym.service.vertical.utility.HttpResponse;
import com.kalsym.service.vertical.utility.Logger;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 *
 * @author hasan
 */
@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;
    
    @Autowired
    private ReservationSlotRepository reservationSlotRepository;

    @Autowired
    private StoreRepository storeRepository;

    public ResponseEntity<HttpResponse> postReservation(HttpServletRequest request,
            String storeId,
            String slotId,
            Reservation bodyReservation) {
        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "bodyReservation: " + bodyReservation.toString());

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationSlot> optReservationSlot = reservationSlotRepository.findById(slotId);

        if (!optReservationSlot.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND slotId: " + slotId);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        List<Reservation> reservations = reservationRepository.findAll();

        bodyReservation.setReservationSlot(optReservationSlot.get());

        for (Reservation existingReservation : reservations) {
            if (existingReservation.getReservationSlot().getId().equals(bodyReservation.getReservationSlot().getId())) {
                Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Slot already reserved", "");
                response.setStatus(HttpStatus.CONFLICT);
                response.setData("Slot Already Reserved");
                return ResponseEntity.status(response.getStatus()).body(response);
            }
        }
        if (bodyReservation.getCustomerNotes() == null) {
            bodyReservation.setCustomerNotes("");
        }

        if (bodyReservation.getStatus() == null) {
            bodyReservation.setStatus(ReservationStatus.WAITING);
        }

        if (bodyReservation.getReservationSlot().getIsReserved() == false) {
            bodyReservation.getReservationSlot().setIsReserved(Boolean.TRUE);
        }

        bodyReservation.setReservationSlot(optReservationSlot.get());
        Reservation savedReservation = reservationRepository.save(bodyReservation);

//        Logger.application.info(ServiceVerticalApplication.VERSION, logprefix, "Reservation Slot added to store with storeId: {}, productId: {}" + storeId, savedProduct.getId());
        response.setStatus(HttpStatus.CREATED);
        response.setData(savedReservation);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    public ResponseEntity<HttpResponse> getReservation(HttpServletRequest request,
            String storeId) {
        String logPrefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        response.setStatus(HttpStatus.OK);
        response.setData(reservationRepository.findAll());
        return ResponseEntity.status(response.getStatus()).body(response);

    }

    public ResponseEntity<HttpResponse> getReservationById(HttpServletRequest request,
            String storeId,
            String id) {
        String logPrefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<Reservation> optReservation = reservationRepository.findById(id);

        if (!optReservation.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND id: " + id);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        response.setStatus(HttpStatus.OK);
        response.setData(optReservation.get());
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    public ResponseEntity<HttpResponse> putReservation(HttpServletRequest request,
            String storeId,
            String id,
            Reservation bodyReservation) {

        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<Reservation> optReservation = reservationRepository.findById(id);

        if (!optReservation.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "NOT_FOUND: {}", id);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation Slot found with Id: {}", id);
        Reservation reservation = optReservation.get();

        reservation.update(bodyReservation);

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation slot updated for Id: " + id, "");
        response.setStatus(HttpStatus.ACCEPTED);
        response.setData(reservationRepository.save(reservation));
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }

    public ResponseEntity<HttpResponse> deleteReservationById(HttpServletRequest request,
            String storeId,
            String id) {
        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<Reservation> optReservation = reservationRepository.findById(id);

        if (!optReservation.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND: " + id, "");
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation found", "");
        reservationRepository.delete(optReservation.get());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation deleted, with id: {}", id);
        response.setStatus(HttpStatus.OK);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

}
