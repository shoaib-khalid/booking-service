/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kalsym.service.vertical.service;

import com.kalsym.service.vertical.ServiceVerticalApplication;
import com.kalsym.service.vertical.enums.AvailabilityDay;
import com.kalsym.service.vertical.model.AvailableSlot;
import com.kalsym.service.vertical.model.ReservationResource;
import com.kalsym.service.vertical.model.ReservationSlot;
import com.kalsym.service.vertical.model.store.Store;
import com.kalsym.service.vertical.repository.ReservationResourceRepository;
import com.kalsym.service.vertical.repository.ReservationSlotRepository;
import com.kalsym.service.vertical.repository.StoreRepository;
import com.kalsym.service.vertical.utility.HttpResponse;
import com.kalsym.service.vertical.utility.Logger;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import static java.time.temporal.ChronoUnit.MINUTES;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

/**
 *
 * @author hasan
 */
@Service
public class ReservationSlotService {

    @Autowired
    private ReservationSlotRepository reservationSlotRepository;

    @Autowired
    private ReservationResourceRepository reservationResourceRepository;

    @Autowired
    private StoreRepository storeRepository;

    public ResponseEntity<HttpResponse> postReservationSlot(HttpServletRequest request,
            String storeId,
            String reservationResourceId,
            ReservationSlot bodyReservationSlot) {
        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "bodyReservationSlot: " + bodyReservationSlot.toString());

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationResource> optReservationResource = reservationResourceRepository.findById(reservationResourceId);

        if (!optReservationResource.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "NOT_FOUND: {}", reservationResourceId);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        List<ReservationSlot> reservationSlots = reservationSlotRepository.findAll();

        for (ReservationSlot existingReservationSlot : reservationSlots) {
            if (existingReservationSlot.getDate().equals(bodyReservationSlot.getDate())
                    && existingReservationSlot.getStartTimeInHours() == bodyReservationSlot.getStartTimeInHours()
                    && existingReservationSlot.getEndTimeInHours() == bodyReservationSlot.getEndTimeInHours()) {
                Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Slot already exists", "");
                response.setStatus(HttpStatus.CONFLICT);
                response.setData("Slot Already Exists");
                return ResponseEntity.status(response.getStatus()).body(response);
            }
        }

        bodyReservationSlot.setDurationInMinutes(optReservationResource.get().getDurationInMinutes());

        if (MINUTES.between(bodyReservationSlot.getStartTimeInHours(), bodyReservationSlot.getEndTimeInHours()) != bodyReservationSlot.getDurationInMinutes()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Invalid starting and ending time according to duration in minutes", "");
            response.setStatus(HttpStatus.CONFLICT);
            response.setData("Invalid starting and ending time according to duration in minutes");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        if (bodyReservationSlot.getStartTimeInHours().isBefore(optReservationResource.get().getStartTime())) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Invalid slot starting time according to resource available starting time", "");
            response.setStatus(HttpStatus.CONFLICT);
            response.setData("Invalid slot starting time according to resource available starting time");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        if (bodyReservationSlot.getEndTimeInHours().isAfter(optReservationResource.get().getEndTime())) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Invalid slot ending time according to resource available ending time", "");
            response.setStatus(HttpStatus.CONFLICT);
            response.setData("Invalid slot ending time according to resource available ending time");
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        if (bodyReservationSlot.getIsReserved() == null) {
            bodyReservationSlot.setIsReserved(Boolean.TRUE);
        }

        bodyReservationSlot.setStartTimeInMillisecondsUTC(convertToMillisecondsEpoch(bodyReservationSlot.getDate(), bodyReservationSlot.getStartTimeInHours()));

        bodyReservationSlot.setEndTimeInMillisecondsUTC(convertToMillisecondsEpoch(bodyReservationSlot.getDate(), bodyReservationSlot.getEndTimeInHours()));

        bodyReservationSlot.setReservationResource(optReservationResource.get());
        ReservationSlot savedReservationSlot = reservationSlotRepository.save(bodyReservationSlot);

        response.setStatus(HttpStatus.CREATED);
        response.setData(savedReservationSlot);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    public ResponseEntity<HttpResponse> getReservationSlot(HttpServletRequest request, String storeId) {
        String logPrefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        response.setStatus(HttpStatus.OK);
        response.setData(reservationSlotRepository.findAll());
        return ResponseEntity.status(response.getStatus()).body(response);

    }

    public ResponseEntity<HttpResponse> getReservationSlotById(HttpServletRequest request,
            String storeId,
            String id) {
        String logPrefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationSlot> optReservationSlot = reservationSlotRepository.findById(id);

        if (!optReservationSlot.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND id: " + id);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        response.setStatus(HttpStatus.OK);
        response.setData(optReservationSlot.get());
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    public ResponseEntity<HttpResponse> getReservedSlots(HttpServletRequest request,
            String storeId) {
        String logPrefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "", "");
        List<ReservationSlot> reservationSlots = reservationSlotRepository.findByIsReserved(Boolean.TRUE);

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        if (reservationSlots.isEmpty()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logPrefix, "Not Found!");
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        response.setStatus(HttpStatus.OK);
        response.setData(reservationSlots);
        return ResponseEntity.status(response.getStatus()).body(response);

    }

    public ResponseEntity<HttpResponse> putReservationSlot(HttpServletRequest request,
            String storeId,
            String id,
            ReservationSlot bodyReservationSlot) {

        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationSlot> optReservationSlot = reservationSlotRepository.findById(id);

        if (!optReservationSlot.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "NOT_FOUND: {}", id);
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation Slot found with Id: {}", id);
        ReservationSlot reservationSlot = optReservationSlot.get();

        Optional<ReservationResource> optReservationResource = reservationResourceRepository.findById(reservationSlot.getReservationResource().getId());

        if (bodyReservationSlot.getStartTimeInHours().isBefore(optReservationResource.get().getStartTime())) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Invalid slot starting time according to resource available starting time", "");
            response.setStatus(HttpStatus.CONFLICT);
            response.setData("Invalid slot starting time according to resource available starting time");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        if (bodyReservationSlot.getEndTimeInHours().isAfter(optReservationResource.get().getEndTime())) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Invalid slot ending time according to resource available ending time", "");
            response.setStatus(HttpStatus.CONFLICT);
            response.setData("Invalid slot ending time according to resource available ending time");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        if (bodyReservationSlot.getStartTimeInHours() != null) {

            if (MINUTES.between(bodyReservationSlot.getStartTimeInHours(), bodyReservationSlot.getEndTimeInHours()) != reservationSlot.getDurationInMinutes()) {
                Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Invalid starting and ending time according to duration in minutes", "");
                response.setStatus(HttpStatus.CONFLICT);
                response.setData("Invalid starting and ending time according to duration in minutes");
                return ResponseEntity.status(response.getStatus()).body(response);
            }
            if (bodyReservationSlot.getDate() == null) {

                bodyReservationSlot.setStartTimeInMillisecondsUTC(convertToMillisecondsEpoch(reservationSlot.getDate(), bodyReservationSlot.getStartTimeInHours()));

            } else {
                bodyReservationSlot.setStartTimeInMillisecondsUTC(convertToMillisecondsEpoch(bodyReservationSlot.getDate(), bodyReservationSlot.getStartTimeInHours()));

            }
        }

        if (bodyReservationSlot.getEndTimeInHours() != null) {

            if (MINUTES.between(bodyReservationSlot.getStartTimeInHours(), bodyReservationSlot.getEndTimeInHours()) != reservationSlot.getDurationInMinutes()) {
                Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Invalid starting and ending time according to duration in minutes", "");
                response.setStatus(HttpStatus.CONFLICT);
                response.setData("Invalid starting and ending time according to duration in minutes");
                return ResponseEntity.status(response.getStatus()).body(response);
            }

            if (bodyReservationSlot.getDate() == null) {

                bodyReservationSlot.setEndTimeInMillisecondsUTC(convertToMillisecondsEpoch(reservationSlot.getDate(), bodyReservationSlot.getEndTimeInHours()));

            } else {
                bodyReservationSlot.setEndTimeInMillisecondsUTC(convertToMillisecondsEpoch(bodyReservationSlot.getDate(), bodyReservationSlot.getEndTimeInHours()));

            }

        }
        reservationSlot.update(bodyReservationSlot);

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation slot updated for Id: " + id, "");
        response.setStatus(HttpStatus.ACCEPTED);
        response.setData(reservationSlotRepository.save(reservationSlot));
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }

    public ResponseEntity<HttpResponse> deleteReservationSlotById(HttpServletRequest request,
            String storeId,
            String id) {
        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "", "");

        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Optional<ReservationSlot> optReservationSlot = reservationSlotRepository.findById(id);

        if (!optReservationSlot.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND: " + id, "");
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation Slot found", "");
        reservationSlotRepository.delete(optReservationSlot.get());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Reservation Slot deleted, with id: {}", id);
        response.setStatus(HttpStatus.OK);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    public ResponseEntity<HttpResponse> getUnreservedSlots(HttpServletRequest request,
            String storeId,
            String productId) {
        String logprefix = request.getRequestURI();
        HttpResponse response = new HttpResponse(request.getRequestURI());
        Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, "Create Slots", "");
        // 1. duration: Time of the resource's availability
        // 2. slot: Valid Time duration falling within the resource's availalibilty duration
        Optional<Store> optStore = storeRepository.findById(storeId);

        if (!optStore.isPresent()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND storeId: " + storeId);
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setError("store not found");
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        List<AvailableSlot> totalSlots = new ArrayList<>();
        List<ReservationResource> reservationResources = reservationResourceRepository.findByProductId(productId);

        if (reservationResources.isEmpty()) {
            Logger.application.info(Logger.pattern, ServiceVerticalApplication.VERSION, logprefix, " NOT_FOUND: " + productId, "");
            response.setStatus(HttpStatus.NOT_FOUND);
            return ResponseEntity.status(response.getStatus()).body(response);
        }

        for (ReservationResource currentReservationResource : reservationResources) {
            LocalTime startTime = currentReservationResource.getStartTime();
            LocalTime endTime = currentReservationResource.getEndTime();
            // ToDo: Need to conform the date in a stardard UTC 
            LocalDate date = LocalDate.now();

            // ToDo: Move the numberOfWeeksReservable from the resource table 
            int numberOfWeeks = currentReservationResource.getNumberOfWeeksReservable();

            // The endDate of the duration for which the slots need to be created
            LocalDate durationEndDate = LocalDate.now().plusWeeks(numberOfWeeks);

            // The duration of allowed slot of the resource
            long slotDuration = currentReservationResource.getDurationInMinutes();
            long durationInMs = slotDuration * 60000;
            
            while (!date.equals(durationEndDate)) {
                LocalTime availabilityStartTime = startTime;
                LocalTime availabilityEndTime = endTime;
                

                long availabilityStartTimeMS = convertToMillisecondsEpoch(date, availabilityStartTime);
                long availabilityEndTimeMS = convertToMillisecondsEpoch(date, availabilityEndTime);
                Logger.application.info("MilliStart = " + availabilityStartTimeMS);
                Logger.application.info("MilliEnd = " + availabilityEndTimeMS);

                String dayAtDate = date.getDayOfWeek().toString();
                String availableDay = currentReservationResource.getAvailabilityDay().toString();

                // The end time of the slot to be created
                LocalTime slotEndTime = availabilityStartTime.plusMinutes(slotDuration);
                Logger.application.info("startTimePlusDuration = " + slotEndTime);

                long slotStartTimeMS = convertToMillisecondsEpoch(date, availabilityStartTime);
                long slotEndTimeMS = convertToMillisecondsEpoch(date, slotEndTime);
                //while (availabilityStartTimeMS <= availabilityEndTimeMS) {
                while (slotEndTimeMS <= availabilityEndTimeMS) {

                    // <editor-fold defaultstate="collapsed" desc="Slots Generation for a day">
                    if (!isReserved(currentReservationResource.getId(), slotStartTimeMS, slotEndTimeMS)) {

                        // Check if the resource's available day matches the current day, so that the slots could be created from today.
                        if (dayAtDate.equals(availableDay)) {
                            AvailableSlot availableSlot = new AvailableSlot();
                            availableSlot.setStartTime(slotStartTimeMS);
                            availableSlot.setEndTime(slotEndTimeMS);
                            availableSlot.setDay(date.getDayOfWeek().toString().toUpperCase());
                            totalSlots.add(availableSlot);//TODO change the strin gcomparison to enum comparison
                        } else if (availableDay.equals("MONDAY_FRIDAY")) {

                            if (!dayAtDate.equals("SATURDAY") && !dayAtDate.equals("SUNDAY")) {
                                AvailableSlot availableSlot = new AvailableSlot();
                                availableSlot.setStartTime(slotStartTimeMS);
                                availableSlot.setEndTime(slotEndTimeMS);
                                availableSlot.setDay(date.getDayOfWeek().toString().toUpperCase());
                                totalSlots.add(availableSlot);
                            }
                        } else if (availableDay.equals("FRIDAY_SUNDAY")) {

                            if (dayAtDate.equals("FRIDAY") || dayAtDate.equals("SATURDAY") || dayAtDate.equals("SUNDAY")) {
                                AvailableSlot availableSlot = new AvailableSlot();
                                availableSlot.setStartTime(slotStartTimeMS);
                                availableSlot.setEndTime(slotEndTimeMS);
                                availableSlot.setDay(date.getDayOfWeek().toString().toUpperCase());
                                totalSlots.add(availableSlot);
                            }

                        } else if (availableDay.equals("SATURDAY_SUNDAY")) {

                            if (dayAtDate.equals("SATURDAY") || dayAtDate.equals("SUNDAY")) {
                                AvailableSlot availableSlot = new AvailableSlot();
                                availableSlot.setStartTime(slotStartTimeMS);
                                availableSlot.setEndTime(slotEndTimeMS);
                                availableSlot.setDay(date.getDayOfWeek().toString().toUpperCase());
                                totalSlots.add(availableSlot);
                            }
                        } else if (availableDay.equals("EVERYDAY")) {
                            AvailableSlot availableSlot = new AvailableSlot();
                            availableSlot.setStartTime(slotStartTimeMS);
                            availableSlot.setEndTime(slotEndTimeMS);
                            availableSlot.setDay(date.getDayOfWeek().toString().toUpperCase());
                            totalSlots.add(availableSlot);
                        }
                    }
                    // </editor-fold>

//                    availabilityStartTime = availabilityStartTime.plusMinutes(slotDuration);
//                    availabilityStartTimeMS = convertToMillisecondsEpoch(date, availabilityStartTime);
                    slotStartTimeMS = slotEndTimeMS;
                    //slotEndTime = slotEndTime.plusMinutes(slotDuration);
                    slotEndTimeMS = slotStartTimeMS + durationInMs;
                }
                date = date.plusDays(1);
            }

        }

        response.setStatus(HttpStatus.OK);
        response.setData(totalSlots);
        return ResponseEntity.status(response.getStatus()).body(response);

    }

    private long convertToMillisecondsEpoch(LocalDate date, LocalTime time) {
        LocalDateTime dt = LocalDateTime.parse(date + "T" + time);
        return dt.toInstant(ZoneOffset.UTC).toEpochMilli();
    }

    private String convertToDatetime(long timeInMilliseconds) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm");
        return dateTimeFormatter.format(LocalDateTime.ofInstant(Instant.ofEpochMilli(timeInMilliseconds), ZoneId.of("UTC")));
    }

    /**
     * Checks if a slot is within the <param>startTime</param> and endTime
     *
     * @param reservationSlotId
     * @param startTime
     * @param endTime
     * @return
     */
    private Boolean isReserved(String reservationSlotId, long startTime, long endTime) {
        List<ReservationSlot> reservationSlots = reservationSlotRepository.findByReservationResourceId(reservationSlotId);
        for (ReservationSlot existingReservationSlot : reservationSlots) {
            if (existingReservationSlot.getStartTimeInMillisecondsUTC() == startTime && existingReservationSlot.getEndTimeInMillisecondsUTC() == endTime) {
                return true;
            }
        }
        return false;
    }

}
