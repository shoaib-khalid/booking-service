package com.kalsym.service.vertical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceVerticalApplicationTests {

	@Test
	void contextLoads() {
	}

}
